﻿using _02_MachineTelemetrySimulator.Models;
using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Text;

namespace _02_MachineTelemetrySimulator.Services
{
    public class MachineSimulator
    {
        private string MachineName;
        TelementryPrinter TelementryPrinter = new();
   
        public MachineSimulator(string machineName)
        {
            MachineName = machineName;
        }

        public async Task RunAsync()
        {
            for (int i = 0; i <= 5; i++)
            {
                TelemetryData telemetryData = new(MachineName, DateTime.UtcNow, GetDouble(40, 100), true);
                TelementryPrinter.Print(telemetryData);
                await Task.Delay(1000);
            }
        }

        public static double GetDouble(double lowerBound, double upperBound)
        {
            var random = new Random();
            var rDouble = random.NextDouble();
            var rRangeDouble = rDouble * (upperBound - lowerBound ) + lowerBound;
            return rRangeDouble;
        }
    }
}
